package com.stock.stockexchange.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stock.stockexchange.model.IpoPlanned;
import com.stock.stockexchange.model.IpoWithoutMapping;

@Repository
public interface IpoPlannedDao extends JpaRepository<IpoWithoutMapping, Integer> {

	@Query("Select s From IpoPlanned s where s.companyCode = :companyCode")

	List<IpoPlanned> findByCompanyId(@Param("companyCode") int companyCode);

	 @Query("Select i From IpoWithoutMapping i where i.ipoId = :ipoId")
	IpoWithoutMapping findByIpoId(@Param("ipoId")int ipoId);

	 @Transactional
		@Modifying
		@Query(value = "DELETE FROM IpoWithoutMapping i  where i.ipoId = :ipoId")
	int deleteCompany(@Param("ipoId")int ipoId);

}
