package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import com.stock.stockexchange.model.CompanyWithoutMapping;
import com.stock.stockexchange.model.IpoWithoutMapping;

public interface IpoService {
	   
		//Insert Ipo
		public IpoWithoutMapping insertIpo(IpoWithoutMapping ipo) throws SQLException;

		
	  
		//Fetch All Ipo List
		public List<IpoWithoutMapping> getIpolist() throws SQLException, ClassNotFoundException;
	 
		

		//Update Company Details Based on given Company code
		public IpoWithoutMapping getUpdateIpoByIpoId(int ipoId);

		//Delete IPo Details Based on selected ipo id
		public int deleteIpo(int ipoId);

}
