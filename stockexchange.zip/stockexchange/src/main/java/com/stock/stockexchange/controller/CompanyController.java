package com.stock.stockexchange.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.CompanyWithoutMapping;
import com.stock.stockexchange.service.CompanyService;

@Controller
@RequestMapping("/companyController")
public class CompanyController {
	@Autowired
	CompanyService companyService;

	@GetMapping(path = "/company")
	public String getCompany(ModelMap model) {
		System.out.println("get empty company pojo");
		CompanyWithoutMapping company = new CompanyWithoutMapping();
		model.addAttribute("company", company);
		System.out.println("go to create new company  page");

		return "CreateCompany";

	}

	@GetMapping(path = "/createCompany")
	public String getCreateCompany(@Valid @ModelAttribute("company") CompanyWithoutMapping company,

			BindingResult result, Model model) {

		String insertCompany = null;
		System.out.println("create company  controller ");
CompanyWithoutMapping  createCompany;
		if (result.hasErrors()) {

			model.addAttribute("company", company);

			insertCompany= "CreateCompany";

		}
		try {
			System.out.println("company  insert method in service calling");
			createCompany = companyService.insertCompany(company);

			if (createCompany != null) {
				System.out.println("after user inserted");
				insertCompany= "redirect:/companyController/fetchCompany";

				System.out.println(insertCompany);
			} else {
				System.out.println(" company not inserted");

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return insertCompany;

	}
	
	
	@GetMapping(path = "/fetchCompany")
	public ModelAndView getFetchCompany(Model model) {
		System.out.println("fetch company controller");
		
		ModelAndView mv = new ModelAndView();
		List<CompanyWithoutMapping> fetchCompany=new ArrayList<CompanyWithoutMapping>();
		try {
			fetchCompany = companyService.getCompanylist();
			if (fetchCompany != null) {
				System.out.println("get all company list");
				model.addAttribute("fetch", fetchCompany);
				mv.setViewName("ManageCompany");
			} else {
				System.out.println("Company is not listed");
				model.addAttribute("list", "there is something error in controller");
				mv.setViewName("ManageCompany");
			}
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		

		return mv;


	}
	

	@GetMapping(path = "/updateCompany")
	public ModelAndView getUpdateCompany(@RequestParam("companyCode") int companyCode,ModelMap model) {
		System.out.println("update company controller "+companyCode);
		
		ModelAndView mv = new ModelAndView();
		CompanyWithoutMapping  updateCompany=new CompanyWithoutMapping();
			updateCompany = companyService.getUpdateCompanyByCompanyCode(companyCode);
			if (updateCompany != null) {
				System.out.println("get company list by company code");
				model.addAttribute("company", updateCompany);
				mv.setViewName("UpdateCompany");
			} else {
				System.out.println("Company is not listed");
				model.addAttribute("list", "there is something error in controller");
				mv.setViewName("UpdateCompany");
			}
		
		

		return mv;


	}
	
	@PostMapping(path = "/saveEditedCompany")
	public String getSaveEditedCompany(@Valid @ModelAttribute("company") CompanyWithoutMapping company,

			BindingResult result, Model model) {

		String insertCompany = null;
		System.out.println("edit company  controller ");
CompanyWithoutMapping  createCompany;
		if (result.hasErrors()) {

			model.addAttribute("company", company);

			insertCompany= "CreateCompany";

		}
		try {
			System.out.println("company  insert method in service calling");
			createCompany = companyService.insertCompany(company);

			if (createCompany != null) {
				System.out.println("after user inserted");
				insertCompany= "redirect:/companyController/fetchCompany";

				System.out.println(insertCompany);
			} else {
				System.out.println(" company not inserted");

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return insertCompany;

	}


	@GetMapping(path = "/deleteCompany")
	public String getDeleteCompany(@RequestParam("companyCode") int companyCode,ModelMap model) {

		String deleteCompany = null;
		System.out.println("delete company  controller ");
int numberOfDeletedRows;
		
			System.out.println("company  delete method in service calling");
			numberOfDeletedRows= companyService.deleteCompany(companyCode);

			if (numberOfDeletedRows != 0) {
				System.out.println("after user deleted");
				deleteCompany= "redirect:/companyController/fetchCompany";

				System.out.println(deleteCompany);
			} else {
				System.out.println(" company not deleted");

			}
		


		return deleteCompany;

	}

}
