package com.stock.stockexchange.model;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
@Table(name = "company")

public class Company {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "company_code")
	private int companyCode;

	@NotNull(message = "Enter required Value")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Company Name should not contain numbers")
	@Column(name = "company_name")
	private String companyName;

	@Column(name = "turnover")
	private BigDecimal turnOver;

	@NotNull(message = "Enter required Value")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Company Name should not contain numbers")
	@Column(name = "ceo")
	private String ceo;

	@NotEmpty(message = "Enter required Value")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Please enter character only")
	@Column(name = "board_of_directors")
	private String boardOfDirectors;

	@NotNull(message = "Enter required Value")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Please enter character only")
	@Column(name = "breif_write_up")
	private String briefWriteUp;

	@Column(name = "stock_exchange_id")
	private int stockCode;

	@ManyToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinColumn(name = "sector_id")
	@JsonBackReference
	private Sector sectors;
	
	@ManyToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinColumn(name = "ipo_id")
	@JsonBackReference
  private IpoPlanned ipoPlanned;
	
	

	public Company() {

	}


	public int getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public BigDecimal getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(BigDecimal turnOver) {
		this.turnOver = turnOver;
	}

	public String getCeo() {
		return ceo;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}

	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}

	public String getBriefWriteUp() {
		return briefWriteUp;
	}

	public void setBriefWriteUp(String briefWriteUp) {
		this.briefWriteUp = briefWriteUp;
	}

	public int getStockCode() {
		return stockCode;
	}

	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}


	public Sector getSectors() {
		return sectors;
	}


	public IpoPlanned getIpoPlanned() {
		return ipoPlanned;
	}



	

}
