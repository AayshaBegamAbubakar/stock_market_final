package com.stock.stockexchange.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.stock.stockexchange.model.StockPrice;
@Repository
public interface StockPriceDao extends JpaRepository<StockPrice, Integer> {

	@Query(value= "Select sum(current_price) From stock_price  where company_id in (select company_code from company where sector_id= :sector_id)",nativeQuery=true)
	float findBySectorId(@Param("sector_id") int sectorId);

}