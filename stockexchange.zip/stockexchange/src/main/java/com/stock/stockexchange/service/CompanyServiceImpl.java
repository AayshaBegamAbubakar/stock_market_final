package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.CompanyDao;
import com.stock.stockexchange.dao.SectorDao;
import com.stock.stockexchange.model.CompanyWithoutMapping;
import com.stock.stockexchange.model.Sector;
@Service

public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private SectorDao  sectorDao;
	
	@Autowired
	private CompanyDao  companyDao;
	
	
	
	

	@Override
	public List<Sector> getCompanyList() throws SQLException, ClassNotFoundException {
		return sectorDao.findAll();
	}





	@Override
	public CompanyWithoutMapping insertCompany(CompanyWithoutMapping company) throws SQLException {
	
	System.out.println("insert company dao");
		return companyDao.save(company);
	}





	public List<CompanyWithoutMapping> findByPattern(String match) {
		// TODO Auto-generated method stub
		return companyDao.findByPattern(match);
	}





	@Override
	public List<CompanyWithoutMapping> getCompanylist() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return companyDao.findAll();
	}





	@Override
	public CompanyWithoutMapping getUpdateCompanyByCompanyCode(int companyCode) {
	       CompanyWithoutMapping fetchCompany=companyDao.findByCompanyCode(companyCode);
	       System.out.println(" fetch company by id "+fetchCompany);
		return fetchCompany;
	}





	@Override
	public int deleteCompany(int companyCode) {
		// TODO Auto-generated method stub
		return companyDao.deleteCompany(companyCode);
	}





	

}

