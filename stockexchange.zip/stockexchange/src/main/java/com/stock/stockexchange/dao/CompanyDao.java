package com.stock.stockexchange.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stock.stockexchange.model.CompanyWithoutMapping;
import com.stock.stockexchange.model.Sector;

@Repository
public interface CompanyDao extends JpaRepository<CompanyWithoutMapping, Integer> {

	@Query("Select s From Sector s where s.sectorId = :sectorId")
	List<Sector> findBySectorId(@Param("sectorId") int sectorId);

	@Query("Select c From Company c where c.companyName like %:match%")
	List<CompanyWithoutMapping> findByPattern(@Param("match") String match);

	@Query("Select c From CompanyWithoutMapping c where c.companyCode = :companyCode")
	CompanyWithoutMapping findByCompanyCode(@Param("companyCode") int companyCode);

	@Transactional
	@Modifying
	@Query(value = "DELETE FROM CompanyWithoutMapping c  where c.companyCode = :companyCode")
	int deleteCompany(@Param("companyCode") int companyCode);

}
